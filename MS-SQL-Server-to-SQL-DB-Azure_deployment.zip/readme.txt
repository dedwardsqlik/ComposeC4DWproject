Original project name: MS SQL Server to SQL DB Azure
Exported on: 08/20/2020 18:04:12
Exported by: damienvmnew\DEdwards
