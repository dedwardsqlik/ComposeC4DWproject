Original project name: MS SQL Server to SQL DB Azure
Exported on: 08/20/2020 17:53:57
Exported by: damienvmnew\DEdwards
