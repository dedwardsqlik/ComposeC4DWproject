Original project name: MS SQL Server to SQL DB Azure
Exported on: 08/20/2020 18:01:49
Exported by: damienvmnew\DEdwards
