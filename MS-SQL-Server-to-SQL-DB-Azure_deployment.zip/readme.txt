Original project name: MS SQL Server to SQL DB Azure
Exported on: 08/20/2020 17:56:44
Exported by: damienvmnew\DEdwards
