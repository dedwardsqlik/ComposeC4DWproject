Original project name: MS SQL Server to SQL DB Azure
Exported on: 08/20/2020 18:02:31
Exported by: damienvmnew\DEdwards
